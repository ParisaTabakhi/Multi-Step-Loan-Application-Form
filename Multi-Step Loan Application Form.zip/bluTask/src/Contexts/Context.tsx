import React, { createContext, useState, useEffect, ReactNode } from "react";
import { fetchData } from '../Service/DataFetcher';

 export interface Loan {
    id: string;
    name: string;
    amount: number;
    interestRate: number; 
    penaltyRate: number; 
    repaymentType: Array<{ value: string; name: string }>;
}

export interface DataContextType {
    data: Loan[];
    error: string;
    loading: boolean;
    setData: React.Dispatch<React.SetStateAction<Loan[]>>;
    selectedLoan: Loan | null;
    setSelectedLoan: React.Dispatch<React.SetStateAction<Loan | null>>;
    selectedrepaymentTypes: number[];
    setSelectedrepaymentTypes: React.Dispatch<React.SetStateAction<number[]>>;
    submissions: any[];
    setSubmissions: React.Dispatch<React.SetStateAction<any[]>>;
}

export const DataContext = createContext<DataContextType | undefined>(undefined);

export const ContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [data, setData] = useState<Loan[]>([]);
    const [error, setError] = useState<string>('');
    const [loading, setLoading] = useState<boolean>(true);
    const [selectedLoan, setSelectedLoan] = useState<Loan | null>(null);
    const [selectedrepaymentTypes, setSelectedrepaymentTypes] = useState<number[]>([]);
    const [submissions, setSubmissions] = useState<any[]>([]);

    useEffect(() => {
        const loadData = async () => {
            setLoading(true);
            try {
                const responseData = await fetchData();
                setData(responseData);
            } catch (err) {
                if (err instanceof Error) {
                    setError(err.message);
                } else {
                    setError('An unknown error occurred.');
                }
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, []);

    return (
        <DataContext.Provider value={{
            data,
            error,
            loading,
            setData,
            selectedLoan,
            setSelectedLoan,
            selectedrepaymentTypes,
            setSelectedrepaymentTypes,
            submissions,
            setSubmissions,
        }}>
            {children}
        </DataContext.Provider>
    );
};
