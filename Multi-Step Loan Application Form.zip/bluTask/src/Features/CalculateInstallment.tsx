import React, { useContext, useMemo, useState, useEffect } from 'react';
import { DataContext, DataContextType } from '../Contexts/Context';


type CalculateInstallmentProps ={
    selectedRepaymentType: number;
}

const CalculateInstallment: React.FC<CalculateInstallmentProps> = ({ selectedRepaymentType }) => {
    const context = useContext(DataContext);


    const { selectedLoan, selectedrepaymentTypes } = context!;

    const amount: number = selectedLoan?.amount || 0; 
    const interestRate: number = selectedLoan?.interestRate || 0; 
    const penaltyRate: number = selectedLoan?.penaltyRate || 0; 

    const [financialData, setFinancialData] = useState<{ latePenalty: number; loanInstallments: number }>({ latePenalty: 0, loanInstallments: 0 });

    const financialCalculations = useMemo(() => {
        const interestAmount = amount * interestRate;
        const totalAmount = interestAmount + amount;
        const computedLatePenalty = amount * penaltyRate; 
        const computedLoanInstallments = totalAmount / selectedRepaymentType;

        return {
            latePenalty: computedLatePenalty,
            loanInstallments: computedLoanInstallments
        };
    }, [amount, interestRate, penaltyRate, selectedrepaymentTypes]);

    useEffect(() => {
        setFinancialData({ latePenalty: 0, loanInstallments: 0 });
    }, [selectedrepaymentTypes]);

    const handleCalculate = () => {
        setFinancialData(financialCalculations);
    };

    return (
        <div className='Calculate'>

            {(financialData.latePenalty > 0 || financialData.loanInstallments > 0) && (
                <div className='flex-column'>
                    <p className="text-medium text-primary mt-1 mb-1">جریمه دیرکرد: {financialData.latePenalty}</p>
                    <p className="text-medium text-primary mt-1 mb-1">قسط تسهیلات: {financialData.loanInstallments}</p>
                </div>
            )}

            {selectedRepaymentType && (
                <button className='button button-calculate' type="button" onClick={handleCalculate}>محاسبه اقساط</button>
            )}
        </div>
    );
};

export default CalculateInstallment;
