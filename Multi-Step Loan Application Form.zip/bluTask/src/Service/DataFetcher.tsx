import axios from "axios";
import { Loan } from '../Contexts/Context';

export const fetchData = async (): Promise<Loan[]> => { 
    try {
        const response = await axios.get('./data.json');
        return response.data.data as Loan[]; 
    } catch (error: any) { 
        throw new Error(error.message);
    }
};
