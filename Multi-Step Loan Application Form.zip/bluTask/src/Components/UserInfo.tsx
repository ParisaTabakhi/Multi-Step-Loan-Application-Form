import React from 'react';
import { UseFormRegister, FieldErrors } from 'react-hook-form';


interface UserInfoProps {
  register: UseFormRegister<any>; 
  errors: FieldErrors<any>; 
}


const UserInfo: React.FC<UserInfoProps> = ({ register, errors }) => {
  return (
    <div>
      <div className='form-group'>
      <label className='text-small' htmlFor='firstName'>نام </label>
      <input
        className='input-form mt-1'
        type='text'
        {...register('firstName', {
          required: 'نام را وارد کنید.',
          minLength: { value: 2, message: 'نام باید حداقل 2 حرف باشد.' },
          maxLength: { value: 30, message: 'نام نمی‌تواند بیشتر از 30 حرف باشد.' },
        })}
      />
      </div>
      {errors.firstName && typeof errors.firstName.message === 'string' && <p className='text-error text-small'>{errors.firstName.message}</p>}
    <div className='form-group'>   
      <label className='text-small' htmlFor='lastName'>نام خانوادگی </label>
      <input
        className='input-form mt-1'
        type='text'
        {...register('lastName', {
          required: 'نام خانوادگی را وارد کنید.',
          minLength: { value: 2, message: 'نام خانوادگی باید حداقل 2 حرف باشد.' },
          maxLength: { value: 30, message: 'نام خانوادگی نمی‌تواند بیشتر از 30 حرف باشد.' },
        })}
      />
      </div> 
      {errors.lastName && typeof errors.lastName.message === 'string' && <p className='text-error text-small'>{errors.lastName.message}</p>}
      <div className='form-group'>  
      <label className='text-small' htmlFor='code'>کد ملی </label>
      <input
        className='input-form mt-1'
        type='text'
        {...register('code', {
          required: 'کدملی را وارد کنید.',
          validate: {
            isNumber: (value) => !isNaN(value) || 'فقط اعداد مجاز هستند.',
            isCorrectLength: (value) => value.length === 10 || 'کد ملی باید 10 رقم باشد.',
          },
        })}
      />
      </div>
      {errors.code && typeof errors.code.message === 'string' && <p className='text-error text-small'>{errors.code.message}</p>}
      <div className='form-group'>  
      <label className='text-small' htmlFor='phoneNumber'>شماره تماس </label>
      <input
        className='input-form mt-1'
        type='text'
        {...register('phoneNumber', {
          required: 'شماره تماس را وارد کنید.',
          validate: {
            isNumber: (value) => !isNaN(value) || 'فقط اعداد مجاز هستند.',
            startsWith09: (value) => value.startsWith('09') || 'شماره تماس باید با 09 شروع شود.',
            isCorrectLength: (value) => value.length === 11 || 'شماره تماس باید 11 رقم باشد.',
          },
        })}
      />
      </div>
      {errors.phoneNumber && typeof errors.phoneNumber.message === 'string' && <p className='text-error text-small'>{errors.phoneNumber.message}</p>}

      <div className='form-group'>      
      <label className='text-small' htmlFor='birthDate'>تاریخ تولد </label>
      <input
       className='input-form mt-1'
        type='date'
        {...register('birthDate', {
          required: 'تاریخ تولد را انتخاب کنید.',
          validate: {
            isAdult: (value) => {
              const today = new Date();
              const birthDate = new Date(value);
              const age = today.getFullYear() - birthDate.getFullYear();
              return age >= 18 || 'سن باید حداقل 18 سال باشد.';
            },
          },
        })}
      />
      </div>
      {errors.birthDate && typeof errors.birthDate.message === 'string' && <p className='text-error text-small'>{errors.birthDate.message}</p>}

    </div>
  );
};

export default UserInfo;
