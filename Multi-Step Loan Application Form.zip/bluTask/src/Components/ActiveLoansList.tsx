import React, { useState, useEffect } from 'react';
import {Link} from 'react-router-dom';

interface LoanSubmission {
    loan: string;
    amount: number;
    repaymentType: string;
    firstName: string;
    lastName: string;
    code: string;
    phoneNumber: string;
    birthDate: string;
    accountNumber: string;
    shabaNumber: string;
    balanceAvrage: number; 
}

const ActiveLoansList: React.FC = () => {
    
    const [loanSubmissions, setLoanSubmissions] = useState<LoanSubmission[]>([]);

    useEffect(() => {
        const storedLoans = JSON.parse(localStorage.getItem('loanSubmissions') || '[]') as LoanSubmission[]; 
        setLoanSubmissions(storedLoans);
    }, []);

    return (
        <div className='width-95'>
            <h1 className='text-primary text-large'>لیست درخواست‌ها</h1>
            <div className='scroll-x'>
            {loanSubmissions.length === 0 ? (
                <p>هیچ درخواستی ثبت نشده است.</p>
            ) : (
                <table  className='table'>
                    <thead>
                        <tr>
                            <th>نوع تسهیلات</th>
                            <th>مبلغ (ريال)</th>
                            <th>مدت بازپرداخت</th>
                            <th>نام</th>
                            <th>نام خانوادگی</th>
                            <th>کد ملی</th>
                            <th>شماره تلفن</th>
                            <th>تاریخ تولد</th>
                            <th>شماره حساب</th>
                            <th>شماره شبا</th>
                            <th>میانگین موجودی (ريال)</th>
                        </tr>
                    </thead>
                    <tbody>
                        {loanSubmissions.map((item, index) => (
                            <tr key={index}>
                                <td>{item.loan}</td>
                                <td>{item.amount}</td>
                                <td>{item.repaymentType}ماهه</td>
                                <td>{item.firstName}</td>
                                <td>{item.lastName}</td>
                                <td>{item.code}</td>
                                <td>{item.phoneNumber}</td>
                                <td>{item.birthDate}</td> 
                                <td>{item.accountNumber}</td>
                                <td>{item.shabaNumber}</td>
                                <td>{item.balanceAvrage}</td> 
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
            </div>
            <Link to='/' className='button button-back'>بازگشت</Link>
        </div>
    );
}

export default ActiveLoansList;
