import React, { useContext } from 'react';
import { DataContext } from '../Contexts/Context';
import { UseFormRegister, FieldErrors } from 'react-hook-form';


interface SelectLoanTypeProps {
    register: UseFormRegister<any>;
    errors: FieldErrors <any>;
    setValue: (name: string, value: any) => void;
}

const SelectLoanType: React.FC<SelectLoanTypeProps> = ({ register, errors, setValue }) => {

    const context = useContext(DataContext);
    const { data , error, loading, setSelectedLoan = () => {} } = context || {};
    
    return (
        <>
            {loading && <p className='text-primary text-center text-large'>در حال بارگذاری...</p>}
            {error ? (
                <div>Error: {error}</div>
            ) : (
                Array.isArray(data) ? (
                    <>
                    <h1 className='text-primary text-large'>انتخاب نوع تسهیلات</h1>
                        {data.map((loan) => (
                            <div key={loan.id}  className='mt-1'>
                                <input 
                                    id={loan.id} 
                                    type="radio" 
                                    value={loan.name} 
                                    {...register('loan', { required: 'لطفا یک گزینه را انتخاب کنید' })} 
                                    onChange={() => {
                                        setSelectedLoan(loan); 
                                        setValue('loan', loan.name);
                                    }}
                                />
                                <label htmlFor={loan.id}>{loan.name + " " + loan.amount + " تومانی "}</label>
                            </div>
                        ))}
                        {errors.loan && <p className='text-error text-small'> {typeof errors.loan.message === 'string' ? errors.loan.message : "خطا در انتخاب گزینه."} </p>}
                    </>
                ) : (
                    <p className='text-error'>نتیجه مورد نظر یافت نشد.</p>
                )
            )}
        </>
    );
};

export default SelectLoanType;
