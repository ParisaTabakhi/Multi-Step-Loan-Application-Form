import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
    return (
        <div className='container bg-light-blue p-4 border-radius'>
            <div className='justify-center flex-column text-center'>
                <h1 className='text-primary text-large'>تسهیلات بانک سامان</h1>
                <>
                <Link to='Form'  className='button button-back'>فرم درخواست</Link>
                <Link to='LoansList' className='button button-primary'>لیست درخواست ها</Link>
                </>
            </div>
        </div>
    );
}

export default Home;
 