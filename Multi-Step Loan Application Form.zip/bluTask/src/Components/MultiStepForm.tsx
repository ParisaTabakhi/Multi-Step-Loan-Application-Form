import React, { useState, useContext } from 'react';
import SelectLoanType from './SelectLoanType';
import { useForm, SubmitHandler, FieldValues } from 'react-hook-form';
import SelectRepaymentType from './SelectRepaymentType';
import UserInfo from './UserInfo';
import BankInfo from './BankInfo';
import { useNavigate } from 'react-router-dom';
import { DataContext, DataContextType } from '../Contexts/Context';

type LoanSubmission = {
    loan: string;
    repaymentType: number;
    firstName: string;
    lastName: string;
    code: string | number;
    phoneNumber: number;
    birthDate: string;
    accountNumber: number;
    shabaNumber: string;
    balanceAvrage: number;
    amount: number;
}

const MultiStepForm: React.FC = () => {
    const context = useContext(DataContext);
    const { handleSubmit, register, setValue, formState: { errors } } = useForm<FieldValues>();
    const [step, setStep] = useState<number>(1);
    const [successMessage, setSuccessMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
    const navigate = useNavigate();

    const { setSubmissions, selectedLoan } = context!;
    const { amount } = selectedLoan || { amount: 0 };


    const saveSubmission = (submission: LoanSubmission) => {
        const existingSubmissions: LoanSubmission[] = JSON.parse(localStorage.getItem('loanSubmissions') || '[]');
        const updatedSubmissions = [...existingSubmissions, submission];
        localStorage.setItem('loanSubmissions', JSON.stringify(updatedSubmissions));
        setSubmissions(updatedSubmissions);
    };


    const onSubmit: SubmitHandler<FieldValues> = async (data) => {
        const updatedData: LoanSubmission = { ...data as LoanSubmission, amount };

        setIsSubmitting(true);
        try {
            saveSubmission(updatedData);
            setSuccessMessage("فرم با موفقیت ارسال شد!");

            setTimeout(() => {
                navigate('/LoansList');
                setSuccessMessage('');
                setIsSubmitting(false);
            }, 2000);

        } catch (error) {
            setErrorMessage("در هنگام ارسال فرم مشکلی پیش آمد. لطفا دوباره تلاش کنید.");
        }
    };

    const nextStep = (data: FieldValues) => {
        if (step === 1) {
            const loanId = data.loan;
        }
        setStep((prev) => prev + 1);
    }

    const backStep = () => {
        setStep((prev) => prev - 1);
    }

    const renderStep = () => {
        switch (step) {
            case 1: return <SelectLoanType register={register} errors={errors} setValue={setValue} />;
            case 2: return <SelectRepaymentType register={register} errors={errors} />;
            case 3: return <UserInfo register={register} errors={errors} />;
            case 4: return <BankInfo register={register} errors={errors} />;
            default: return null;
        }
    };

    return (
        <div className='bg-light-blue container border-radius'>
            <form onSubmit={handleSubmit(step === 4 ? onSubmit : nextStep)}  className='p-2 form'>
                {renderStep()}
            <div className='button-group'>
                 <button type='submit' disabled={isSubmitting} className='button button-primary mt-1'>
                    {isSubmitting ? 'در حال ارسال...' : (step === 4 ? 'ارســال' : 'ادامــه')}
                </button>
                {step > 1 && 
                <button  className='button button-back mt-1' type='button'  onClick={backStep}>قبلی</button>}
                </div>
            </form>
            {successMessage && <p className='text-success'>{successMessage}</p>}
            {errorMessage && <p className='text-error'>{errorMessage}</p>}
        </div>
    );
}

export default MultiStepForm;
