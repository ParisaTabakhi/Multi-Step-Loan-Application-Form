import React, { useState, useContext } from 'react';
import CalculateInstallment from '../Features/CalculateInstallment';
import { DataContext } from '../Contexts/Context';
import { UseFormRegister, FieldErrors } from 'react-hook-form';

interface RepaymentType {
    value: string;
    name: string;
}

interface SelectRepaymentTypeProps {
    register: UseFormRegister<any>;
    errors: FieldErrors;
}

const SelectRepaymentType: React.FC<SelectRepaymentTypeProps> = ({ register, errors }) => {
    const dataContext = useContext(DataContext);
    const selectedLoan = dataContext?.selectedLoan;
    const [selectedRepaymentType, setSelectedRepaymentType] = useState<number>();

    const repaymentTypes: RepaymentType[] = selectedLoan ? selectedLoan.repaymentType : [];

    const handleRepaymentTypeChange = (typeValue: any) => {
        setSelectedRepaymentType(typeValue);
        dataContext?.setSelectedrepaymentTypes([typeValue]);
    };

    return (
        <>
            <h2 className='text-primary text-large'>انتخاب نوع بازپرداخت</h2>
            <div className='side-by-side'>
                <div>
            {repaymentTypes.map((type) => (
                <div key={type.value}>
                    <input 
                        type="radio"
                        value={type.value}
                        {...register('repaymentType', { required: 'لطفا یک گزینه را انتخاب کنید' })}
                        onChange={() => handleRepaymentTypeChange(type.value)}
                    />
                    <label>{type.name}</label>
                </div>
            ))}
                </div>
            {errors.repaymentType && <p className='text-error text-small'>{(errors.repaymentType.message as string)}</p>}
            {selectedRepaymentType && <CalculateInstallment selectedRepaymentType={selectedRepaymentType} />}
            </div>
        </>
    );
}

export default SelectRepaymentType;
