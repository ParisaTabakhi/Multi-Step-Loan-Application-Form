import React from 'react';
import { UseFormRegister, FieldErrors } from 'react-hook-form';

interface BankInfoProps {
    register: UseFormRegister<any>;
    errors: FieldErrors<any>;
}

const BankInfo: React.FC<BankInfoProps> = ({ register, errors }) => {
    return (
        <>
            <div>
            <div className='form-group'> 
                <label className='text-small' htmlFor='accountNumber'>شماره حساب :</label>
                <input
                className='input-form mt-1' 
                    type='text' 
                    id='accountNumber'
                    {...register('accountNumber', {
                        required: 'شماره حساب را وارد کنید.',
                        pattern: {
                            value: /^[0-9]+$/,
                            message: 'فقط اعداد مجاز است.'
                        }
                    })}
                />
                </div>
                {errors.accountNumber && <p className='text-error text-small'>{errors.accountNumber.message as string}</p>}
                <div className='form-group'> 
                <label className='text-small' htmlFor='shabaNumber'> شماره شبا :</label>
                <input
                className='input-form mt-1' 
                    type='text' 
                    id='shabaNumber'
                    {...register('shabaNumber', {
                        required: 'شماره شبا را وارد کنید.',
                        minLength: {
                            value: 24,
                            message: 'شماره شبا باید 24 کاراکتر باشد.'
                        },
                        maxLength: {
                            value: 24,
                            message: 'شماره شبا نمی‌تواند بیشتر از 24 کاراکتر باشد.'
                        }
                    })}
                />
               </div>     
                {errors.shabaNumber && <p className='text-error text-small'>{errors.shabaNumber.message as string}</p>}
               <div className='form-group'>     
                <label className='text-small' htmlFor='balanceAvrage'> میانگین ریالی موجودی سالیانه :</label>
                <input
                className='input-form mt-1' 
                    type='text' 
                    id='balanceAvrage'
                    {...register('balanceAvrage', {
                        required: 'میانگین ریالی موجودی سالیانه را وارد کنید.',
                        pattern: {
                            value: /^[0-9]+$/,
                            message: 'فقط اعداد مجاز است.'
                        }
                    })}
                />
                </div>

                {errors.balanceAvrage && <p className='text-error text-small'>{errors.balanceAvrage.message as string}</p>}
            </div>
        </>
    );
}

export default BankInfo;
