import React from 'react'; 
import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './Components/Home'
import MultiStepForm from './Components/MultiStepForm';
import { ContextProvider } from './Contexts/Context';
import ActiveLoansList from './Components/ActiveLoansList';

const App: React.FC = () => {
  return (
    <>
      <ContextProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/Form" element={<MultiStepForm />} />
            <Route path="/LoansList" element={<ActiveLoansList />} />
          </Routes>
        </BrowserRouter>
      </ContextProvider>
    </>
  );
}

export default App;


